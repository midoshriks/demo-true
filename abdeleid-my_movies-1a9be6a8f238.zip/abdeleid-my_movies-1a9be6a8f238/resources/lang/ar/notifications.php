<?php

return [
    'notifications' => 'الاشعارات',
    'notification' => 'الاشعار',
    'text' => 'النص',
];