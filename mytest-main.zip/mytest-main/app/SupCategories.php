<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupCategories extends Model
{
    protected $fillable = ['name','code','cat_code'];

     public function subcategory()
    {
        return $this->hasMany(\App\Models\Category::class, 'code');
    }

    public function parent()
    {
        return $this->belongsTo(\App\Models\Category::class, 'code');
    }

}